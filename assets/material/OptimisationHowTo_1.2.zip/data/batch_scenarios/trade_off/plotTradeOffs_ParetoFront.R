##====================================================
## Haean Opt2
##====================================================
# display pareto front of trade-offs

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# ADJUST THE FILE PATH HERE TO THE data/batch_scenarios/trade_off FOLDER!
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
tradeoffPath = "E:/OptimisationHowTo_1.2/data/batch_scenarios/trade_off"


#**********************************************
#		DEFINE FUNCTIONS
#**********************************************

library(rgl)
setwd(tradeoffPath)

# this is handy for plotting the permutations of 'uncertainties' used
# in the S9_HaeanOpt_tradeOff_constGM.los file, i.e.
# UNCERTAINTIES=0,0  0,1  0,2  0,3  0,4 ...
# just uncommented line 29
plotPermute <- function()
{
  for(i in 0:13)
  {
    for (j in 0:13)
    {
      #cat(i, ",", j, " ");
    }
  }
}

# need to set the right
createFrontDF <- function()
{
  # structure of rel_file: Area	Biomass	CropYield	Gr.Margin	Nleach	Sediment	SurfRunoff
  vNL = vector(mode="numeric", length=196);
  vSY = vector(mode="numeric", length=196);
  vGM = vector(mode="numeric", length=196);
  vAR = vector(mode="numeric", length=196);
  vBI = vector(mode="numeric", length=196);
  vCY = vector(mode="numeric", length=196);
  vSR = vector(mode="numeric", length=196);
  vFN = vector(mode="character", length=196);

  counter = 1;
  for (i in 0:13)
  {
   for (j in 0:13)
    {
      #i=3
      #j=8
      fn = paste0("rel_HaeanOpt_2_p", i, "+", j, "-1.csv");

      resdf = read.csv(fn, header=TRUE, sep=",", quote="\"");
      vNL[counter] = resdf$e_Nleach_REL[5];
      vSY[counter] = resdf$e_Sediment_REL[5];
      vGM[counter] = resdf$e_GrossMargin_REL[5];
      vAR[counter] = resdf$AreaHa_REL[5];
      vBI[counter] = resdf$e_Biomass_REL[5];
      vCY[counter] = resdf$e_CropYield_REL[5];
      vSR[counter] = resdf$e_SurfRunoff_REL[5];
      vFN[counter] = fn;

      counter = counter + 1
    }
  }

  frontDf = data.frame(vAR, vBI, vCY, vGM, vNL, vSY, vSR, vFN);
  colnames(frontDf) <- c("Area", "Biomass", "CropYield", "GrossMargin", "Nleach", "Sediment", "SurfRunoff", "FileName");
  return (frontDf);

}

#**********************************************
#		DO THE PLOTTING & ANIMATION
#**********************************************

# pull the information together using the function defined above
df = createFrontDF();

# write the data frame into as CSV file for later use
write.csv(df, file="rel_tradeOffScenarios.csv")

# plot the data
plot3d(df$Nleach, df$Sediment, df$GrossMargin, col="red", size=2, type="s")

# animate the data
movie3d(spin3d(axis = c(0,0,1), rpm = 10), duration=6, frames="pff_", type = "png")















